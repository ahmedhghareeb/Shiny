This app shows a side-by-side comparison of select and selectize input
elements, i.e. `selectInput(..., selectize = FALSE)` vs `selectizeInput(...)`.
