It's possible to include files with HTML, text, or Markdown content in a Shiny app.

HTML files will be included as-is, text files will have characters escaped, and Markdown files will be processed into HTML with the markdown package before inclusion.

Be sure to look at the full source code for this app, since it has files other than ui.R and server.R.
